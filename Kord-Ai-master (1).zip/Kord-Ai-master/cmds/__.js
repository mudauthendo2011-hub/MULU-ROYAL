/* 
 * Copyright © 2025 Kenny
 * This file is part of Kord and is licensed under the GNU GPLv3.
 */

const os = require("os")
const { changeFont } = require("../core")
const { prefix, kord, wtype, secondsToHms, config, commands } = require("../core")
const { version } = require("../package.json")

const format = (bytes) => {
  const sizes = ["B", "KB", "MB", "GB"]
  if (bytes === 0) return "0 B"
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return parseFloat((bytes / Math.pow(1024, i)).toFixed(1)) + " " + sizes[i]
}

const getRandomFont = () => "sansItalic"

kord({
  cmd: "menu|help",
  desc: "list of commands",
  react: "💬",
  fromMe: wtype,
  type: "help",
}, async (m) => {
  try {
    const types = {}
    commands.forEach(({ cmd, type }) => {
      if (!cmd) return
      const main = cmd.split("|")[0].trim()
      const cat = type || "other"
      if (!types[cat]) types[cat] = []
      types[cat].push(main)
    })

    const requestedType = m.text ? m.text.toLowerCase().trim() : null
    const availableTypes = Object.keys(types).map(t => t.toLowerCase())
    
    const more = String.fromCharCode(8206)
    const readmore = more.repeat(4001)
    
    // Category-specific menu
    if (requestedType && availableTypes.includes(requestedType)) {
      const actualType = Object.keys(types).find(t => t.toLowerCase() === requestedType)
      const at = await changeFont(actualType.toUpperCase(), "monospace")
      const cmdList = types[actualType].map(cmd => `│ ${prefix}${cmd.replace(/[^a-zA-Z0-9-+]/g, "")}`).join('\n')
      const formattedCmds = await changeFont(cmdList, getRandomFont())
      
      const styledBody = await changeFont(
        ` ┏ ${at} ┓
┍   ─┉─ • ─┉─    ┑ 
${formattedCmds}
┕    ─┉─ • ─┉─   ┙ 
Tip: Use ${prefix}menu to see all categories`, getRandomFont()
      )
      
      const final = `\`\`\`┌─═━┈ アニメ・Sector X ┈━═─┐
   ▸ Owner: mudau thendo
   ▸ Name: mulu
   ▸ User: tusha
  
INFO: Use .gc for official community info
🔗 Join the community: https://chat.whatsapp.com/JdCeTIp4tbG8XHAXGWCrcF
└───────═━┈┈━═──────┘\`\`\`
${readmore}

📌 Category Image:
https://cdn.kord.live/serve/ifU5XNhHQL1y.jpg

${styledBody}`
      return m.send(final)
    }
    
    // Full menu
    const categoryList = Object.keys(types).map(async (type) => {
      const cmdList = types[type].map(cmd => `│ ${prefix}${cmd.replace(/[^a-zA-Z0-9-+]/g, "")}`).join('\n')
      const formattedCmds = await changeFont(cmdList, getRandomFont())
      const tty = await changeFont(type.toUpperCase(), "monospace")
      
      return ` ┏ ${tty} ┓
┍   ─┉─ • ─┉─    ┑ 
${formattedCmds}
┕    ─┉─ • ─┉─   ┙ `
    })

    const resolvedCategoryList = await Promise.all(categoryList)

    let menu = `\`\`\`┌─═━┈ アニメ・Sector X ┈━═─┐
   ▸ Owner: mudau thendo
   ▸ Name: mulu
   ▸ User: 𝑺𝒆𝒄𝒕𝒐𝒓 𝑿 𝒃𝒐𝒕
   ▸ Memory: 18.9 GB
   ▸ Version: v2.0.0
INFO: Use .gc for official community info
🔗 Join the community: https://chat.whatsapp.com/JdCeTIp4tbG8XHAXGWCrcF
└───────═━┈┈━═──────┘\`\`\`
${readmore}

📌 Category Image:
https://cdn.kord.live/serve/ifU5XNhHQL1y.jpg

${resolvedCategoryList.join('\n\n')}

Tip: Use ${prefix}menu [category] for specific commands`.trim()

    try {
      if (config().MENU_IMAGE) return m.send(config().MENU_IMAGE, { caption: menu }, "image")
    } catch(e) {}

    return m.send(menu)

  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
}) 
