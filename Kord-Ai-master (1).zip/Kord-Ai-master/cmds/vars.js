/* 
 * Copyright © 2025 Kenny
 * This file is part of Kord and is licensed under the GNU GPLv3.
 * And I hope you know what you're doing here.
 * You may not use this file except in compliance with the License.
 * See the LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
 * -------------------------------------------------------------------------------
 */

const { kord, wtype, updateConfig, prefix, updateEnv, updateEnvSudo, addEnvSudo, removeEnvSudo, replaceEnvSudo, getEnvValue, envExists, listEnvKeys, toBoolean, getPlatformInfo, setVar, updateVar, delVar, getVars, config, myMods, getAdmins 
  } = require("../core")
  const fs = require("fs")
  
  
  
kord({
  cmd: "setvar",
  desc: "set a config in config.env/config.js",
  fromMe: true,
  type: "config",
}, async (m, text)=> {
  try {
  if (!text)  return await m.send(`*provide the var name and value*\n_example: ${prefix}setvar SESSION_ID=kord-ai_321`)
  var [key, ...args] = text.split("=")
  key = key.toUpperCase()
  var value = args.join("=").trim()
  if (!key || !value) return await m.send(`*provide the var name and value*\n_example: ${prefix}setvar SESSION_ID kord-ai_321`) 
  const platformInfo = getPlatformInfo()
  if (platformInfo.platform === "render") {
    try {
      await m.send(`*_Config Successfully Set_* *${key.toUpperCase()}* _to_ *${value}*\n_Restarting..._`)
      await setVar(key.toUpperCase(), value)
    } catch (error) {
      await m.send(`*Error setting variable:* ${error.message}`)
    }
  } else {
    var isExist = await envExists()
    if (isExist) {
      if (!process.env[key]) {
        await updateEnv(key, value)
        return await m.send(`*Config set successfully!*\n\n_Created ${key} with value ${value}_`)
      } else {
        await updateEnv(key, value)
        return await m.send(`*Config set successfully!*`)
      }
    } else {
      await updateConfig(key, value)
      return await m.send(`*Config set successfully!*`)
    }
  }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

kord({
cmd: "getvar",
  desc: "get all variables from config.js/config.env",
  fromMe: true,
  type: "config",
}, async (m, text) => {
  try {
    if (!text) return m.reply("_*provide var name...*_\n_example: getvar SUDO_")
    const key = text.trim().toUpperCase()
    if (typeof key !== 'string' || !key.trim()) {
    await m.reply("_*Invalid variable!...*_")
    } else if (await envExists()) {
    return await m.send(`*${key}*: ${process.env[key]}`)
    } else if (config()[key]) {
    return await m.send(`*${key}*: ${config()[key]}`)
    } else {
    await m.reply(`_*'${key}' not found in config*_`)
    }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

kord({
  cmd: 'delvar',
  desc: "delete a variable/setting",
  fromMe: true,
  type: "config",
}, async (m, text) => {
  try {
  const key = text.trim().toUpperCase()
  const platformInfo = getPlatformInfo()
  if (platformInfo.platform === "render") {
    try {
      await m.send(`_*successfully deleted ${key}*_\n\n> restarting..`)
      await delVar(key)
    } catch (error) {
      await m.send(`*Error deleting variable:* ${error.message}`)
    }
  } else {
    var isExist = await envExists()
    if (isExist) {
      await updateEnv(key, null, { remove: true})
    } else {
      await updateConfig(key, null, {remove: true})
    }
    await m.send(`_*successfully deleted ${key}*_`)
  }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

kord({
  cmd: "allvar",
  desc: "get all variables/settings",
  fromMe: true,
  type: "config",
}, async (m, text)=> {
  try {
  const platformInfo = getPlatformInfo()
  
  if (platformInfo.platform === "render") {
    try {
      const result = await getVars()
      if (result.success) {
  var data = '*All Vars (Render)*\n\n'
  for (var item of result.data) {
    const variable = item.envVar
    data += `*${variable.key}*: ${variable.value}\n`
  }
  return await m.send(data)
}
    } catch (error) {
      await m.send(`*Error getting variables:* ${error.message}`)
      return
    }
  }
  if (await envExists()) {
    var h = await listEnvKeys()
      var daa = '*All Vars*\n\n'
    for (var hh of h) {
      daa += `*${hh}*: ${process.env[hh]}\n`
    }
    return await m.send(`${daa}`)
  } else {
    const data = '*All Vars*\n\n' + Object.keys(config())
    .map(key => `*${key}:* ${config()[key]}`)
    .join('\n')
    return await m.send(`${data}`)
  }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

async function updateAllConfig(key, value, m) {
  const platformInfo = getPlatformInfo()
  if (platformInfo.platform === "render") {
    try {
      await m.send(`*_${key} set to ${value}_*\n_Restarting..._`)
      if (process.env[key]) {
        await setVar(key, value)
      } else {
        await setVar(key, value)
      }
    } catch (error) {
      await m.send(`*Error updating variable:* ${error.message}`)
    }
  } else {
    var isExist = await envExists()
    if (isExist) {
      if (!process.env[key]) {
        await updateEnv(key, value)
        return await m.send(`*_${key} set to ${value}_*`)
      } else {
        await updateEnv(key, value)
        return await m.send(`*_${key} set to ${value}_*`)
      }
    } else {
      await updateConfig(key, value)
      return await m.send(`*_${key} set to ${value}_*`)
    }
  }
}

function toggle(cmdName, envKey, displayName) {
  try {
  return async (m, text, cmd) => {
    const allowed = [...myMods().map(x => x + '@s.whatsapp.net'), m.ownerJid]
    text = text.split(" ")[0].toLowerCase()
    const validInputs = ['on', 'off', 'true', 'false']

if (!text) {
  if (config().RES_TYPE.toLowerCase() === "button") {
    return await m.btnText("*Toggle on/off*", {
      [`${cmd} on`]: "ON",
      [`${cmd} off`]: "OFF",
    })
  } else if (config().RES_TYPE.toLowerCase() === "poll") {
    return await m.send({
      name: "*Toggle on/off*",
      values: [{ name: "on", id: `${cmdName} on` }, { name: "off", id: `${cmdName} off` }],
      withPrefix: true,
      onlyOnce: true,
      participates: allowed,
      selectableCount: true,
    }, {}, "poll")
  } else {
    return await m.send(`*Use:* ${cmd} on/off`)
  }
}

if (!validInputs.includes(text)) {
  return await m.send(`*Invalid option:* _${text}_\n_Use only 'on', 'off', 'true', or 'false'_`)
}
    
    var t = toBoolean(text)
    var envVal = process.env[envKey]
    var configVal = config()[envKey]
    if ((envVal !== undefined && toBoolean(envVal) == t) || (configVal !== undefined && toBoolean(configVal) == t)) {
  return await m.send(`*${displayName} already set to ${text}..*`)
    }
    
    await updateAllConfig(envKey, text, m)
  }
  } catch (e) {
    console.log("cmd error", e)
    return m.sendErr(e)
  }
}

function deltog() {
  try {
    return async (m, text, cmd) => {
      const allowed = [...myMods().map(x => x + '@s.whatsapp.net'), m.ownerJid]
      text = text.split(" ")[0].toLowerCase()
      const validInputs = ['on', 'p', 'chat', 'g', 'off']

      if (text && !validInputs.includes(text) && !text.match(/^\d+$/)) {
        return await m.send(`*Invalid option:* _${text}_\n_Use: 'on/p' (owner), 'chat/g' (in chat), 'off' (disable), or phone number_`)
      }

      if (!text) {
        if (config().RES_TYPE.toLowerCase() === "button") {
          return await m.btnText("*Antidelete Settings*", {
            [`${cmd} on`]: "TO OWNER",
            [`${cmd} chat`]: "IN CHAT",
            [`${cmd} off`]: "DISABLE",
          })
        } else if (config().RES_TYPE.toLowerCase() === "poll") {
          return await m.send({
            name: "*Antidelete Settings*",
            values: [
              { name: "To Owner", id: `${cmd} on` },
              { name: "In Chat", id: `${cmd} chat` },
              { name: "Disable", id: `${cmd} off` }
            ],
            withPrefix: true,
            onlyOnce: true,
            participates: allowed,
            selectableCount: true,
          }, {}, "poll")
        } else {
          return await m.send(`*Use:* ${cmd} on/p/chat/g/off or phone number\n\n*Options:*\n• on/p - Send to owner\n• chat/g - Send in chat\n• off - Disable\n• [number] - Send to specific number`)
        }
      }

      let finalValue = text
      if (text.match(/^\d+$/)) {
        finalValue = text
      }

      var envVal = process.env.ANTIDELETE
      var configVal = config().ANTIDELETE
      if ((envVal !== undefined && envVal === finalValue) || (configVal !== undefined && configVal === finalValue)) {
        return await m.send(`*Anti Delete already set to ${text}..*`)
      }

      await updateAllConfig('ANTIDELETE', finalValue, m)
    }
  } catch (e) {
    console.log("cmd error", e)
    return m.sendErr(e)
  }
}


kord({
  cmd: "readstatus",
  desc: "turn on/off readstatus",
  fromMe: true,
  type: "config",
}, toggle("readstatus", "STATUS_VIEW", "Read Status"))

kord({
  cmd: "likestatus",
  desc: "turn on/off likestatus",
  fromMe: true,
  type: "config",
}, toggle("likestatus", "LIKE_STATUS", "Like Status"))

kord({
  cmd: "startupmsg",
  desc: "turn on/off startupmsg",
  fromMe: true,
  type: "config",
}, toggle("startupmsg", "STARTUP_MSG", "Startup Msg"))


kord({
  cmd: "alwaysonline",
  desc: "turn on/off always online",
  fromMe: true,
  type: "config",
}, toggle("alwaysonline", "ALWAYS_ONLINE", "Always Online"))

kord({
  cmd: "antidelete",
  desc: "configure antidelete settings",
  fromMe: true,
  type: "config",
}, deltog())


kord({
  cmd: "antiedit",
  desc: "turn on/off Anti-Edit",
  fromMe: true,
  type: "config",
}, toggle("antiedit", "ANTI_EDIT", "Anti Edit"))

kord({
  cmd: "antieditchat",
  desc: "turn on/off antiedit in chat",
  fromMe: true,
  type: "config",
}, toggle("antieditchat", "ANTI_EDIT_IN_CHAT", "Anti Edit In Chat"))

kord({
  cmd: "savestatus",
  desc: "turn on/off save status",
  fromMe: true,
  type: "config",
}, toggle("savestatus", "SAVE_STATUS", "Save Status"))

kord({
  cmd: "cmdreact",
  desc: "turn on/off command react",
  fromMe: true,
  type: "config",
}, toggle("cmdreact", "CMD_REACT", "Command React"))

kord({
  cmd: "readmsg|read",
  desc: "turn on/off read message",
  fromMe: true,
  type: "config",
}, toggle("readmsg", "READ_MESSAGE", "Read Message"))

kord({
  cmd: "rejectcall",
  desc: "turn on/off reject call",
  fromMe: true,
  type: "config",
}, toggle("rejectcall", "REJECT_CALL", "Reject Call"))

updateEnv("SUDO", nsn)
    return await m.send(`\`\`\`${toAdd.join(', ')} added to sudo list...\`\`\``)
  } else {
    await updateConfig("SUDO", nsn, { replace: true })
    return await m.send(`\`\`\`${toAdd.join(', ')} added to sudo list...\`\`\``)
  }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})


/**
 * protecters.js
 * Mods & Guards system for MUDAU-R
 *
 * Commands:
 *  - .mods             -> mention all mods & guards (public)
 *  - .addmod <number>  -> add mod (owner only)
 *  - .delmod <number>  -> delete mod (owner only)
 *  - .addguard <number>-> add guard (owner only)
 *  - .delguard <number>-> delete guard (owner only)
 *
 * Owner number: 27799648540
 */

const fs = require('fs');
const path = require('path');

// Owner number
const OWNER_NUMBER = '27799648540';

// Paths
const DB_DIR = path.join(__dirname, '..', 'database');
const MODS_FILE = path.join(DB_DIR, 'mods.json');
const GUARDS_FILE = path.join(DB_DIR, 'guards.json');

// ensure database folder and files exist
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
if (!fs.existsSync(MODS_FILE)) fs.writeFileSync(MODS_FILE, JSON.stringify({ mods: [] }, null, 2));
if (!fs.existsSync(GUARDS_FILE)) fs.writeFileSync(GUARDS_FILE, JSON.stringify({ guards: [] }, null, 2));

// helpers
function readJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch { return null; }
}

function writeJson(filePath, obj) {
  fs.writeFileSync(filePath, JSON.stringify(obj, null, 2));
}

function getSenderNumber(message) {
  return message?.sender || message?.from || message?.key?.participant || message?.author || '';
}

function isOwner(message) {
  return getSenderNumber(message).replace('+','') === OWNER_NUMBER;
}

// build panel with mentions instead of numbers
function buildPanel(modsArr, guardsArr) {
  let txt = '';
  txt += '╭━━━★彡 アニメ・Sector X 彡★━━━╮\n';
  txt += '│  👑 Animal Sector X 👑        │\n';
  txt += '│  📌 Mods & Guards list       │\n';
  txt += '╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n';

  txt += '🛡️ GUARDS 🛡️\n';
  if (!guardsArr || guardsArr.length === 0) txt += '  None\n\n';
  else guardsArr.forEach(g => txt += `@${g}\n`);

  txt += '\n⚔️ MODS ⚔️\n';
  if (!modsArr || modsArr.length === 0) txt += '  None\n\n';
  else modsArr.forEach(m => txt += `@${m}\n`);

  txt += '\n──────────────────────────────\n';
  txt += '⚠️ Warning: Do NOT misuse mod powers.\n';
  txt += 'Unauthorized actions can lead to a ban from Animal Sector X bot or community.\n';
  txt += '──────────────────────────────';
  return txt;
}

// commands
module.exports = {
  name: 'protecters',
  commands: {

    mods: {
      description: 'Mention all Mods & Guards (public)',
      run: async (bot, message, args) => {
        const modsData = readJson(MODS_FILE) || { mods: [] };
        const guardsData = readJson(GUARDS_FILE) || { guards: [] };

        // build panel with mentions
        const panel = buildPanel(modsData.mods, guardsData.guards);
        await bot.sendMessage(message.from, { text: panel });
      }
    },

    addmod: {
      description: 'Add a Mod (owner only)',
      run: async (bot, message, args) => {
        if (!isOwner(message)) return bot.sendMessage(message.from, { text: '❌ Only owner can use this.' });
        if (!args[0]) return bot.sendMessage(message.from, { text: '❌ Usage: .addmod <number>' });

        const number = args[0].trim();
        const data = readJson(MODS_FILE) || { mods: [] };
        if (data.mods.includes(number)) return bot.sendMessage(message.from, { text: '⚠️ Already a mod.' });

        data.mods.push(number);
        writeJson(MODS_FILE, data);
        await bot.sendMessage(message.from, { text: `✅ Added @${number} as a Mod.` });
      }
    },

    delmod: {
      description: 'Delete a Mod (owner only)',
      run: async (bot, message, args) => {
        if (!isOwner(message)) return bot.sendMessage(message.from, { text: '❌ Only owner can use this.' });
        if (!args[0]) return bot.sendMessage(message.from, { text: '❌ Usage: .delmod <number>' });

        const number = args[0].trim();
        const data = readJson(MODS_FILE) || { mods: [] };
        if (!data.mods.includes(number)) return bot.sendMessage(message.from, { text: '⚠️ Not a mod.' });

        data.mods = data.mods.filter(n => n !== number);
        writeJson(MODS_FILE, data);
        await bot.sendMessage(message.from, { text: `✅ Deleted @${number} from Mods.` });
      }
    },

    addguard: {
      description: 'Add a Guard (owner only)',
      run: async (bot, message, args) => {
        if (!isOwner(message)) return bot.sendMessage(message.from, { text: '❌ Only owner can use this.' });
        if (!args[0]) return bot.sendMessage(message.from, { text: '❌ Usage: .addguard <number>' });

        const number = args[0].trim();
        const data = readJson(GUARDS_FILE) || { guards: [] };
        if (data.guards.includes(number)) return bot.sendMessage(message.from, { text: '⚠️ Already a guard.' });

        data.guards.push(number);
        writeJson(GUARDS_FILE, data);
        await bot.sendMessage(message.from, { text: `✅ Added @${number} as a Guard.` });
      }
    },

    delguard: {
      description: 'Delete a Guard (owner only)',
      run: async (bot, message, args) => {
        if (!isOwner(message)) return bot.sendMessage(message.from, { text: '❌ Only owner can use this.' });
        if (!args[0]) return bot.sendMessage(message.from, { text: '❌ Usage: .delguard <number>' });

        const number = args[0].trim();
        const data = readJson(GUARDS_FILE) || { guards: [] };
        if (!data.guards.includes(number)) return bot.sendMessage(message.from, { text: '⚠️ Not a guard.' });

        data.guards = data.guards.filter(n => n !== number);
        writeJson(GUARDS_FILE, data);
        await bot.sendMessage(message.from, { text: `✅ Deleted @${number} from Guards.` });
      }
    }

  }
};
kord({
  cmd: "savecmd",
  desc: "set save emoji",
  fromMe: true,
  type: "config",
}, async (m, text) => {
  try {
    if (!text) return await m.send("_provide an emoji_\n_example: savecmd 🤍")
    await updateAllConfig("SAVE_CMD", text, m)
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

kord({
  cmd: "vvcmd",
  desc: "set vv emoji",
  fromMe: true,
  type: "config",
}, async (m, text) => {
  try {
    if (!text) return await m.send("_provide an emoji_\n_example: vvcmd 🤍")
    await updateAllConfig("VV_CMD", text, m)
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})
