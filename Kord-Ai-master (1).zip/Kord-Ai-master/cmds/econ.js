/* 
 * Copyright © 2025 Kenny
 * This file is part of Kord and is licensed under the GNU GPLv3.
 * Updated by 🙃🩵JUSTICE BY JUNIOR🩵🙃
 * Royal style economy commands with shop
 */

const { kord, prefix, wtype, config, getData, storeData } = require("../core")
const fs = require("fs")
const path = require("path")
const edb = require("../core/edb")

// MongoDB connection
let con
if (config().MONGODB_URI) {
  con = edb.connect(config().MONGODB_URI)
} else {
  con = undefined
}

const k = "kord"
const stored = path.join(__dirname, '..', 'core', 'store')

// Royal Economy Activation
kord({
  cmd: "economy|econ",
  desc: "Manage economy commands",
  fromMe: wtype,
  type: "economy"
}, async (m, text) => {
  try {
    if (!config().MONGODB_URI || config().MONGODB_URI === "") {
      return await m.send("```You need to set MONGODB_URI at config\nexample setvar MONGODB_URI=your url..```")
    }

    var edata = await getData("econ") || []

    if (text && text.toLowerCase() === "off") {
      if (!edata.includes(m.chat)) return await m.send("```📉 Economy commands are already deactivated```")
      edata = edata.filter(chat => chat !== m.chat)
      await storeData("econ", edata)
      return await m.send("```📉 Economy commands deactivated```")
    }

    if (text && text.toLowerCase() === "on") {
      if (edata.includes(m.chat)) return await m.send("```📈 Economy commands are already active```")
      edata.push(m.chat)
      await storeData("econ", edata)
      return await m.send("```📈 Economy commands activated```")
    }

    if (!edata.includes(m.chat)) {
      edata.push(m.chat)
      await storeData("econ", edata)
      return await m.send("```📈 Economy commands activated```")
    }

  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Royal Balance Command
kord({
  cmd: "bal|wallet",
  desc: "[economy] Shows user's balance",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")

    const b = await edb.balance(m.sender, k)
    return await m.send(
`🎴 👑 ROYAL ACCOUNT 👑 🎴
━━━━━━━━━━━━━━━━━
💎 Wallet: 〘 \`\`\`₹${b.wallet}\`\`\` 〙
🏦 Bank: 〘 \`\`\`${b.bank}/₹${b.bankCapacity}\`\`\` 〙
🌌 Max Bank: 〘 \`\`\`${b.bankCapacity}\`\`\` 〙
━━━━━━━━━━━━━━━━━
✨ Total Wealth: 〘 \`\`\`${b.wallet+b.bank}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Daily Command
kord({
  cmd: "daily",
  desc: "[economy] Claim daily coins",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")

    const d = await edb.daily(m.sender, k, 1001)
    if (d.cd) {
      return await m.send(`⏳ You have already claimed today!
⏱️ Return in: ${d.cdL}
━━━━━━━━━━━━━━━━━`)
    }

    const newBal = await edb.balance(m.sender, k)
    return await m.send(
`🎴 👑 ROYAL DAILY REWARD 👑 🎴
━━━━━━━━━━━━━━━━━
🎁 Claimed: 〘 \`\`\`${d.amount}\`\`\` 〙
💎 New Balance: 〘 \`\`\`${newBal.wallet}\`\`\` 〙
⏱️ Cooldown: 〘 \`\`\`24 Hours\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Deposit Command
kord({
  cmd: "dep|deposit",
  desc: "[economy] Deposit money to bank",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    if (!text) return await m.send("```⚠️ Please specify amount to deposit```")

    const amount = text.toLowerCase() === "all" ? "all" : parseInt(text)
    if (amount !== "all" && (isNaN(amount) || amount <= 0)) return await m.send("```❌ Please provide a valid amount```")

    const result = await edb.deposit(m.sender, k, amount)
    if (result.noten) return await m.send("```💸 Insufficient wallet balance```")

    const newBal = await edb.balance(m.sender, k)
    return await m.send(
`🎴 👑 ROYAL BANK DEPOSIT 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Deposited: 〘 \`\`\`${result.amount}\`\`\` 〙
💎 Wallet: 〘 \`\`\`${newBal.wallet}\`\`\` 〙
🏦 Bank: 〘 \`\`\`${newBal.bank}/${newBal.bankCapacity}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Withdraw Command
kord({
  cmd: "with|withdraw",
  desc: "[economy] Withdraw money from bank",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    if (!text) return await m.send("```⚠️ Please specify amount to withdraw```")

    const amount = text.toLowerCase() === "all" ? "all" : parseInt(text)
    if (amount !== "all" && (isNaN(amount) || amount <= 0)) return await m.send("```❌ Please provide a valid amount```")

    const result = await edb.withdraw(m.sender, k, amount)
    if (result.noten) return await m.send("```💸 Insufficient bank balance```")
    if (result.invalid) return await m.send("```❌ Invalid amount specified```")

    const newBal = await edb.balance(m.sender, k)
    return await m.send(
`🎴 👑 ROYAL BANK WITHDRAW 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Withdrawn: 〘 \`\`\`${result.amount}\`\`\` 〙
💎 Wallet: 〘 \`\`\`${newBal.wallet}\`\`\` 〙
🏦 Bank: 〘 \`\`\`${newBal.bank}/${newBal.bankCapacity}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Give / Pay Command
kord({
  cmd: "give|pay",
  desc: "[economy] Give money to someone",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    if (!m.quoted && !text) return await m.send("```⚠️ Reply to someone or mention with amount```")

    let target = m.quoted ? m.quoted.sender : m.mentions[0]
    let amount = text ? parseInt(text.split(" ")[1] || text) : parseInt(text)

    if (!target) return await m.send("```❌ Please specify who to pay```")
    if (isNaN(amount) || amount <= 0) return await m.send("```❌ Please provide valid amount```")
    if (target === m.sender) return await m.send("```😂 You cannot pay yourself```")

    const senderBal = await edb.balance(m.sender, k)
    if (senderBal.wallet < amount) return await m.send("```💸 Insufficient wallet balance```")

    await edb.deduct(m.sender, k, amount)
    await edb.give(target, k, amount)

    return await m.send(
`🎴 👑 ROYAL PAYMENT 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Amount: 〘 \`\`\`${amount}\`\`\` 〙
👤 To: 〘 \`\`\`${target.split("@")[0]}\`\`\` 〙
💎 Your Balance: 〘 \`\`\`${senderBal.wallet - amount}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Work Command
kord({
  cmd: "work",
  desc: "[economy] Work to earn money",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")

    const result = await edb.work(m.sender, k)
    if (result.cd) return await m.send(`😴 You are still recovering from work!\n⏱️ Return in: ${result.cdL}\n━━━━━━━━━━━━━━━━━`)

    const jobs = ["Royal Chef", "Royal Guard", "Court Artist", "Palace Scholar", "Royal Engineer", "Royal Musician", "Royal Merchant", "Royal Healer"]
    const job = jobs[Math.floor(Math.random() * jobs.length)]

    return await m.send(
`🎴 👑 ROYAL WORK 👑 🎴
━━━━━━━━━━━━━━━━━
👷 Job: 〘 \`\`\`${job}\`\`\` 〙
💰 Earned: 〘 \`\`\`${result.amount}\`\`\` 〙
⏱️ Cooldown: 〘 \`\`\`${result.cdL}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Rob Command
kord({
  cmd: "rob",
  desc: "[economy] Attempt to rob someone",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    if (!m.quoted && !m.mentions[0]) return await m.send("```⚠️ Reply to someone or mention to rob```")

    const target = m.quoted ? m.quoted.sender : m.mentions[0]
    if (target === m.sender) return await m.send("```😂 You cannot rob yourself```")

    const result = await edb.rob(m.sender, k, target)
    if (result.cd) return await m.send(`⏳ You recently attempted robbery\n⏱️ Return in: ${result.cdL}\n━━━━━━━━━━━━━━━━━`)
    if (result.lowbal) return await m.send("💸 Target doesn't have enough money to rob")

    if (result.success) return await m.send(
`🎴 👑 ROYAL ROBBERY 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Stolen: 〘 \`\`\`${result.amount}\`\`\` 〙
👤 From: 〘 \`\`\`${target.split("@")[0]}\`\`\` 〙
😈 You got away successfully!
━━━━━━━━━━━━━━━━━`
    )

    return await m.send(
`🚨 ROYAL ROBBERY FAILED
💸 Fine: 〘 \`\`\`${result.fine}\`\`\` 〙
👮 Caught by palace guards!
😢 Better luck next time
━━━━━━━━━━━━━━━━━`
    )
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Gamble / Bet Command
kord({
  cmd: "gamble|bet",
  desc: "[economy] Gamble your money",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    if (!text) return await m.send("```⚠️ Please specify amount to gamble```")

    const amount = parseInt(text)
    if (isNaN(amount) || amount <= 0) return await m.send("```❌ Please provide valid amount```")

    const userBal = await edb.balance(m.sender, k)
    if (userBal.wallet < amount) return await m.send("```💸 Insufficient wallet balance```")

    const win = Math.random() > 0.5
    if (win) {
      const winAmount = Math.floor(amount * (1 + Math.random()))
      await edb.give(m.sender, k, winAmount)
      return await m.send(
`🎴 👑 ROYAL GAMBLING 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Bet: 〘 \`\`\`${amount}\`\`\` 〙
🎉 Won: 〘 \`\`\`${winAmount}\`\`\` 〙
💎 Profit: 〘 \`\`\`${winAmount}\`\`\` 〙
━━━━━━━━━━━━━━━━━`
      )
    } else {
      await edb.deduct(m.sender, k, amount)
      return await m.send(
`🎴 👑 ROYAL GAMBLING 👑 🎴
━━━━━━━━━━━━━━━━━
💰 Bet: 〘 \`\`\`${amount}\`\`\` 〙
😢 Lost: 〘 \`\`\`${amount}\`\`\` 〙
🎲 Better luck next time!
━━━━━━━━━━━━━━━━━`
      )
    }
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Leaderboard
kord({
  cmd: "lb|leaderboard|top",
  desc: "[economy] Show richest users",
  fromMe: wtype,
  type: "economy",
}, async (m, text) => {
  try {
    var x = await getData("econ") || []
    if (!x.includes(m.chat)) return await m.send("```💎 Economy is not activated here```")
    const count = parseInt(text) || 10
    const lb = await edb.lb(k, count > 20 ? 20 : count)
    if (lb.length === 0) return await m.send("```📊 No users found in economy```")

    let msg = `🎴 👑 ROYAL LEADERBOARD 👑 🎴\n━━━━━━━━━━━━━━━━━\n`
    for (let i = 0; i < lb.length; i++) {
      const pos = i + 1
      const user = lb[i]
      const total = user.wallet + user.bank
      const medal = pos === 1 ? "🥇" : pos === 2 ? "🥈" : pos === 3 ? "🥉" : `${pos}.`
      msg += `${medal} @${user.userID.split("@")[0]}: 〘 \`\`\`${total}\`\`\` 〙\n`
    }
    msg += "━━━━━━━━━━━━━━━━━"
    return await m.send(msg)
  } catch (e) {
    console.log("cmd error", e)
    return await m.sendErr(e)
  }
})

// Royal Shop (20 items)
const royalShop = [
  { name: "Excalibur Sword", price: 5000, description: "Legendary sword of kings" },
  { name: "Royal Crown", price: 3000, description: "Symbol of noble power" },
  { name: "Magic Potion 🧪", price: 1200, description: "Restores royal energy" },
  { name: "Royal Fish 🐟", price: 900, description: "Increases luck in gambling" },
  { name: "Golden Shield", price: 3500, description: "Protects from robbery" },
  { name: "Royal Cape", price: 2000, description: "Boosts work earnings" },
  { name: "Diamond Ring 💎", price: 4000, description: "Rare luxury item" },
  { name: "Royal Necklace", price: 2500, description: "Noble accessory" },
  { name: "Magic Scroll", price: 1500, description: "Grants wisdom" },
  { name: "Enchanted Boots", price: 1800, description: "Faster work cooldown" },
  { name: "Royal Lamp", price: 2200, description: "Increases daily reward" },
  { name: "Treasure Map", price: 2700, description: "Unlocks hidden wealth" },
  { name: "Royal Banner", price: 1000, description: "Show off your status" },
  { name: "Palace Key", price: 3000, description: "Access secret
