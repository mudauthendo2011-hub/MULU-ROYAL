# MUDAU-R WhatsApp Bot 🤖

MUDAU-R is a powerful and fully-featured WhatsApp bot with economy, moderation, and fun commands. Built with Node.js, it is designed to run 24/7 and make group management and engagement super easy! ⚡

---

## Features ✨

### 🛡️ Moderation
- Add and remove **mods & guards**
- Mute / unmute users in groups
- Pin / unpin messages
- Set group name & description
- Anti-link protection
- Welcome & goodbye messages

### 🎴 Economy System
- Wallet & bank system
- Work, daily, gamble, rob, and give commands
- Leaderboards & rich list
- Shop with customizable items (20+ items supported)

### 🎮 Games
- Tic-Tac-Toe (`.ttt`)
- Word Challenge Game (`.wcg`)

### 🔗 Utility
- Group management commands (`.add`, `.kick`, `.invite`, etc.)
- Fun commands like `.joke`, `.quote`, etc.
- Customizable bot prefix and settings

---

## Setup 🛠️

1. Clone the repository:

```bash
git clone https://github.com/yourusername/mudau-r.git
cd mudau-r

## Fore more info:
DM +27799648540 on whatsapp
